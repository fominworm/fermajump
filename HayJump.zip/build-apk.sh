set -e
cd "$(dirname "$0")"
mkdir -p www && cp index.html manifest.webmanifest icon-192.png icon-512.png www/
npm install
npx cap add android
npx cap sync android
R=android/app/src/main/res
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do cp icon/$d/*.png $R/mipmap-$d/; done
printf '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n  <color name="ic_launcher_background">#8FD3FF</color>\n</resources>\n' > $R/values/ic_launcher_background.xml
sed -i 's/<activity /<activity android:screenOrientation="portrait" /' android/app/src/main/AndroidManifest.xml
cd android && chmod +x gradlew && ./gradlew assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk ../FermaJump.apk
