# 🌾 Ферма Джамп
Дудл Джамп на ферме. Управление: кнопки или наклон (Настройки в меню). Тап по экрану — выстрел яйцом.
Разработчик: tg **flomaster6** — https://t.me/flomaster6 · Неофициальная фан-игра.

Загрузи `HayJump.zip` в корень репозитория, включи Settings → Pages → Source: GitHub Actions, положи `.github/workflows/deploy.yml` (содержимое — `deploy.yml` из архива).
APK: Actions → Deploy → Run workflow → внизу запуска Artifacts → FermaJump-APK.
Название приложения меняется в `capacitor.config.json` (appName).
